# Cerol / Arex web page (Next.js, plain JavaScript)

Copy these folders and files into a fresh Next.js project:

1. `npx create-next-app@latest cerol-arex-web`
   Choose: JavaScript (not TypeScript), App Router, no Tailwind, no `src/` folder, import alias `@/*`.
2. `cd cerol-arex-web` and `npm install next-view-transitions docx nodemailer`
3. Copy `app/`, `components/`, `data/`, `lib/`, `messages/`, `public/` and `next.config.mjs` from this folder
   into the project and overwrite when asked.
4. Delete `app/page.js` and `app/layout.js` (and `app/page.module.css` if it exists).
   The site now starts at `app/[locale]/layout.js`.
5. `npm run dev` and open http://localhost:3000 (it redirects to /bs).

Hiring form: the application is made into a Word file and e-mailed to info@cerol.ba by `app/api/apply/route.js`.
It needs a mail account to send from: copy `.env.example` to `.env.local` and fill in the SMTP details
(mail server, user and password). Without them the form shows "not sent" and nothing is lost silently.

Where to edit things:
- Stations, hours, phones, services: `data/stations.js`
- Brand colors and logos: `data/brands.js`
- Station photos: put the file in `public/images/stations/`, then add `image: "/images/stations/<station-id>.jpg"` to that station in `data/stations.js` (optional `imagePosition: "75% 40%"` picks the part that stays visible when the photo is cropped)
- Texts in Bosnian, English, German: `messages/*.json`
- Welcome message on the home page: `home.welcomeLines` in `messages/*.json` (each entry is one line of the animation)
- Look and page transition: `app/globals.css`
- Welcome animation timing: the `animation-delay` / duration values of `.welcome__text`, `.welcome__rule`, `.home__lead` and `.stations__list` in `app/globals.css` (people who prefer reduced motion see everything at once)

TODO: Arex Mionica phone number, the Cerol logo, and real content for the Management, About us and Hiring pages (they show a placeholder text for now).
