/** @type {import('next').NextConfig} */
const nextConfig = {
  // The site lives under /bs, /en and /de, so send "/" to the default language.
  async redirects() {
    return [{ source: "/", destination: "/bs", permanent: false }];
  },
};

export default nextConfig;
