// Both brands use the red from the logo. Each station page and the home page
// use this palette for the background gradient.
const red = {
  primary: "#D32027", // logo red
  dark: "#8E1218",
  deeper: "#4A0A0E",
  silver: "#A7A9AC", // logo silver
};

export const siteColors = red;

export const brands = {
  Arex: {
    logo: "/images/arex-logo.png",
    logoSize: { width: 215, height: 75 },
    colors: red,
  },
  Cerol: {
    // TODO: add public/images/cerol-logo.png, then set logo and logoSize here.
    logo: null,
    logoSize: null,
    colors: red,
  },
};
