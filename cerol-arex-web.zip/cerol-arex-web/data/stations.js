// All station data lives in this file. Edit it to change what the site shows.

// Services that every station offers.
export const commonServices = [
  "eurodiesel",
  "premium95",
  "adblue",
  "shop",
  "restroom",
  "cafe",
];

// image (optional): a photo in public/images/stations/, shown faded behind the station page.
// extraServices can be a plain string ("rooms") or an object
// ({ key: "heatingOil", deliveryOnly: true }).
export const stations = [
  {
    id: "arex-kerep",
    name: "Arex Kerep",
    intro: true, // plays the brand emblem animation when the page opens
    image: "/images/stations/arex-kerep.jpg",
    imagePosition: "50% 65%",
    brand: "Arex",
    address: "Kerep bb",
    city: "Gradačac",
    zip: "76250",
    hours: { open: "00:00", close: "24:00" },
    phones: [
      { number: "+38735861111" },
      { number: "+38735861222" },
      { number: "+38735861333", label: "fax" },
    ],
    lat: 44.8239376,
    lng: 18.4544376,
    mapsUrl: "https://maps.app.goo.gl/qXbW24gZ4G4fiiQR6",
    extraServices: ["lng", { key: "heatingOil", deliveryOnly: true }],
  },
  {
    id: "arex-mionica",
    name: "Arex Mionica",
    intro: true,
    image: "/images/stations/arex-mionica.jpg",
    imagePosition: "40% 62%",
    brand: "Arex",
    address: "Mionica bb",
    city: "Gradačac",
    zip: "76250",
    hours: { open: "06:00", close: "23:00" },
    phones: [], // TODO: add the Mionica phone number
    lat: 44.866968,
    lng: 18.4723483,
    mapsUrl: "https://maps.app.goo.gl/BAVibx7EMsFon8tr8",
    extraServices: ["selfServiceCarWash"],
  },
  {
    id: "cerol-cerik",
    name: "Cerol Cerik",
    brand: "Cerol",
    address: "Cerik bb",
    city: "Brčko Distrikt",
    zip: "76215",
    hours: { open: "00:00", close: "24:00" },
    phones: [{ number: "+38749746149", label: "officeFax" }],
    lat: 44.8082216,
    lng: 18.5330192,
    mapsUrl: "https://maps.app.goo.gl/sY4rwmxMtGkAYwki6",
    image: "/images/stations/cerol-cerik.jpg",
    imagePosition: "48% 40%",
    extraServices: [],
  },
  {
    id: "cerol-brcko",
    name: "Cerol Brčko",
    brand: "Cerol",
    address: "Bijeljinska 7",
    city: "Brčko Distrikt",
    zip: "76100",
    hours: { open: "00:00", close: "24:00" },
    phones: [
      { number: "+38749233021", label: "station" },
      { number: "+38749232220", label: "office" },
    ],
    lat: 44.8696169,
    lng: 18.8181904,
    mapsUrl: "https://maps.app.goo.gl/i2k9nrjhbbTKaUgV9",
    image: "/images/stations/cerol-brcko.jpg",
    imagePosition: "75% 40%", // which part of the photo stays in view when it is cropped
    extraServices: ["selfServiceCarWash"],
  },
  {
    id: "cerol-samac",
    name: "Cerol Šamac",
    brand: "Cerol",
    address: "Škarić bb",
    city: "Šamac",
    zip: "76230",
    hours: { open: "00:00", close: "24:00" },
    phones: [{ number: "+38754622031" }],
    lat: 45.0419931,
    lng: 18.4532302,
    mapsUrl: "https://maps.app.goo.gl/NQYDmMUzhH2HhoHS7",
    image: "/images/stations/cerol-samac.jpg",
    imagePosition: "56% 40%",
    extraServices: ["lng", "rooms", "selfServiceCarWash"],
  },
];

export const getStation = (id) => stations.find((s) => s.id === id);

// Turns "rooms" into { key: "rooms" } so every service has the same shape.
const normalizeService = (s) => (typeof s === "string" ? { key: s } : s);

export const getServices = (station) =>
  [...commonServices, ...station.extraServices].map(normalizeService);
