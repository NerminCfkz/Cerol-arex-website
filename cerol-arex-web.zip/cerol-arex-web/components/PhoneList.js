// +38735861111 -> +387 35 861 111
const pretty = (n) => n.replace(/^\+387(\d{2})(\d{3})(\d{3})$/, "+387 $1 $2 $3");

export default function PhoneList({ phones, t }) {
  if (!phones.length) return null;

  return (
    <ul className="phones">
      {phones.map((p) => (
        <li key={p.number}>
          {p.label && (
            <span className="phones__label">{t.phoneLabels[p.label]}: </span>
          )}
          {p.label === "fax" ? (
            <span>{pretty(p.number)}</span>
          ) : (
            <a href={`tel:${p.number}`}>{pretty(p.number)}</a>
          )}
        </li>
      ))}
    </ul>
  );
}
