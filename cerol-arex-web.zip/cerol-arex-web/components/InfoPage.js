import { siteColors } from "@/data/brands";

// Simple page with a big title. Used for Management, About us and Hiring
// until their real content is added.
export default function InfoPage({ title, text, children }) {
  const c = siteColors;

  return (
    <main
      className="page"
      style={{
        "--c-primary": c.primary,
        "--c-dark": c.dark,
        "--c-deeper": c.deeper,
        "--c-silver": c.silver,
      }}
    >
      <div className="wrap">
        <h1 className="page__title">{title}</h1>
        {text && <p className="page__lead">{text}</p>}
        {children}
      </div>
    </main>
  );
}
