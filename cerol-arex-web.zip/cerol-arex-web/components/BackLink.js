import AppLink from "./AppLink";

// Return button to the home page (uses the same page transition as every link).
export default function BackLink({ locale, label, className = "" }) {
  return (
    <AppLink href={`/${locale}`} className={`back ${className}`.trim()}>
      {label}
    </AppLink>
  );
}
