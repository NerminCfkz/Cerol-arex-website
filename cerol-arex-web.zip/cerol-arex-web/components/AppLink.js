"use client";

// One place for all internal links, so every navigation gets the
// page transition from next-view-transitions.
import { Link } from "next-view-transitions";

export default function AppLink(props) {
  return <Link {...props} />;
}
