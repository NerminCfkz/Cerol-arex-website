"use client";

import { useState } from "react";

const MIN_YEAR = 1940;
const MIN_AGE = 16;

// Application form: every field has its own input box.
// Previous employment is optional (it can be a first job).
const FIELDS = [
  { name: "station", select: true },
  { name: "firstName", autoComplete: "given-name", row: 1 },
  { name: "lastName", autoComplete: "family-name", row: 1 },
  { name: "birthYear", inputMode: "numeric", autoComplete: "bday-year", row: 2 },
  { name: "residence", autoComplete: "address-level2", row: 2 },
  { name: "education", autoComplete: "off" },
  { name: "employment", multiline: true, optional: true },
];

export default function HiringForm({ t, stations }) {
  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState("idle"); // idle | sending | done | error

  const maxYear = new Date().getFullYear() - MIN_AGE;

  function validate(data) {
    const result = {};
    for (const f of FIELDS) {
      const value = (data[f.name] ?? "").trim();
      if (!value && !f.optional) result[f.name] = t.required;
    }
    if (!result.birthYear) {
      const year = Number(data.birthYear);
      if (!Number.isInteger(year) || year < MIN_YEAR || year > maxYear) {
        result.birthYear = t.yearInvalid
          .replace("{min}", MIN_YEAR)
          .replace("{max}", maxYear);
      }
    }
    return result;
  }

  async function onSubmit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    const found = validate(data);
    setErrors(found);
    setStatus("idle");

    const first = FIELDS.find((f) => found[f.name]);
    if (first) {
      form.elements[first.name].focus();
      return;
    }

    setStatus("sending");
    try {
      const response = await fetch("/api/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!response.ok) throw new Error("Request failed");
      form.reset();
      setStatus("done");
    } catch {
      setStatus("error");
    }
  }

  return (
    <form className="apply" onSubmit={onSubmit} noValidate>
      {FIELDS.map((f) => {
        const id = `apply-${f.name}`;
        const error = errors[f.name];
        const common = {
          id,
          name: f.name,
          autoComplete: f.autoComplete,
          "aria-invalid": error ? "true" : undefined,
          "aria-describedby": error ? `${id}-error` : undefined,
          required: !f.optional,
        };
        return (
          <div className={`apply__field apply__field--${f.row ?? 0}`} key={f.name}>
            <label htmlFor={id}>
              {t[f.name]}
              {f.optional && <span className="apply__opt"> ({t.optional})</span>}
            </label>
            {f.select ? (
              <select {...common} defaultValue="">
                <option value="" disabled>
                  {t.chooseStation}
                </option>
                {stations.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            ) : f.multiline ? (
              <textarea {...common} rows={4} />
            ) : (
              <input type="text" inputMode={f.inputMode} {...common} />
            )}
            {error && (
              <p className="apply__error" id={`${id}-error`}>
                {error}
              </p>
            )}
          </div>
        );
      })}

      <button className="apply__submit" type="submit" disabled={status === "sending"}>
        {status === "sending" ? t.sending : t.submit}
      </button>

      <p className="apply__status" role="status">
        {status === "done" && t.success}
        {status === "error" && <span className="apply__error">{t.error}</span>}
      </p>
    </form>
  );
}
