// Shop, restroom, café, car wash, rooms...
export default function ServiceList({ items, t }) {
  if (!items.length) return null;

  return (
    <ul className="rows">
      {items.map((s) => (
        <li key={s.key}>
          <span>{t.services[s.key] ?? s.key}</span>
          {s.deliveryOnly && (
            <span className="rows__note">{t.station.deliveryOnly}</span>
          )}
        </li>
      ))}
    </ul>
  );
}
