"use client";

import { usePathname } from "next/navigation";
import AppLink from "./AppLink";
import { locales } from "@/lib/i18n";

// Keeps the visitor on the same page and only swaps the language prefix:
// /bs/stations/arex-kerep -> /en/stations/arex-kerep
export default function LanguageSwitcher({ locale }) {
  const pathname = usePathname();
  const rest = pathname.split("/").slice(2).join("/");

  return (
    <nav className="lang" aria-label="Language">
      {locales.map((l) => (
        <AppLink
          key={l}
          href={rest ? `/${l}/${rest}` : `/${l}`}
          aria-current={l === locale ? "true" : undefined}
          lang={l}
        >
          {l.toUpperCase()}
        </AppLink>
      ))}
    </nav>
  );
}
