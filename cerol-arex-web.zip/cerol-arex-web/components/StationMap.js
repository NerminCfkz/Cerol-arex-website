import { mapsLink, directionsLink, embedLink } from "@/lib/maps";

export default function StationMap({ station, t }) {
  return (
    <div className="map">
      <iframe
        src={embedLink(station)}
        title={station.name}
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        allowFullScreen
      />
      <div className="map__links">
        <a
          className="btn"
          href={mapsLink(station)}
          target="_blank"
          rel="noopener noreferrer"
        >
          {t.station.openInMaps}
        </a>
        <a
          className="btn btn--quiet"
          href={directionsLink(station)}
          target="_blank"
          rel="noopener noreferrer"
        >
          {t.station.directions}
        </a>
      </div>
    </div>
  );
}
