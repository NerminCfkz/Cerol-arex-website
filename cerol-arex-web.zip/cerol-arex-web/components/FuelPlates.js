// Fuel and AdBlue, shown like labels on a pump.
export default function FuelPlates({ items, t }) {
  if (!items.length) return null;

  return (
    <>
      <h2 className="fuel__title">{t.station.fuelTitle}</h2>
      <ul className="fuel">
        {items.map((s) => (
          <li key={s.key} className="fuel__plate">
            <span className="fuel__name">{t.services[s.key] ?? s.key}</span>
            {s.deliveryOnly && (
              <span className="fuel__note">{t.station.deliveryOnly}</span>
            )}
          </li>
        ))}
      </ul>
    </>
  );
}
