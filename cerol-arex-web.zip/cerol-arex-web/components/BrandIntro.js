import Image from "next/image";

// Short opening animation with the brand emblem. It is pure CSS: the emblem
// is wiped in on a white plate, a silver line is drawn under it, then the
// whole layer fades away and shows the station page. It never blocks clicks
// and is hidden for people who prefer reduced motion.
export default function BrandIntro({ brand, logo, size }) {
  return (
    <div className="intro" aria-hidden="true">
      <div className="intro__plate">
        <Image
          className="intro__logo"
          src={logo}
          alt=""
          width={size.width}
          height={size.height}
          loading="eager"
          priority
        />
      </div>
      <span className="intro__rule" />
    </div>
  );
}
