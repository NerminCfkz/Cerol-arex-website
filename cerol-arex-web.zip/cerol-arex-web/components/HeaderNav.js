"use client";

import { useEffect, useId, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import AppLink from "./AppLink";

// Main menu. On wide screens it is a row of buttons; on phones it sits behind
// the menu button (the three bars).
export default function HeaderNav({ locale, labels }) {
  const pathname = usePathname();
  const menuId = useId();
  const toggle = useRef(null);

  // The menu counts as open only on the page where it was opened,
  // so it closes by itself after you go to another page.
  const [openPath, setOpenPath] = useState(null);
  const open = openPath === pathname;

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e) => {
      if (e.key === "Escape") {
        setOpenPath(null);
        toggle.current?.focus();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [open]);

  const base = `/${locale}`;
  const items = [
    // The main page and the station pages both belong to "Gas stations".
    {
      key: "stations",
      href: base,
      current: pathname === base || pathname.startsWith(`${base}/stations`),
    },
    { key: "management", href: `${base}/management`, current: pathname === `${base}/management` },
    { key: "about", href: `${base}/about`, current: pathname === `${base}/about` },
    { key: "hiring", href: `${base}/hiring`, current: pathname === `${base}/hiring` },
  ];

  return (
    <>
      <button
        ref={toggle}
        type="button"
        className="nav__toggle"
        aria-expanded={open}
        aria-controls={menuId}
        aria-label={labels.menu}
        onClick={() => setOpenPath(open ? null : pathname)}
      >
        <span className="nav__bars" aria-hidden="true" />
      </button>

      <nav id={menuId} className={open ? "nav is-open" : "nav"} aria-label={labels.menu}>
        <ul className="nav__list">
          {items.map((item) => (
            <li key={item.key}>
              <AppLink
                href={item.href}
                className="nav__link"
                aria-current={item.current ? "page" : undefined}
              >
                {labels[item.key]}
              </AppLink>
            </li>
          ))}
        </ul>
      </nav>
    </>
  );
}
