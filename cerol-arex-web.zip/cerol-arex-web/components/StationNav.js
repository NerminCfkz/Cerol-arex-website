import AppLink from "./AppLink";

// Navigation with one outline pill per gas station.
export default function StationNav({ stations, locale, label }) {
  return (
    <nav className="stations" aria-label={label}>
      <ul className="stations__pills" style={{ "--n": stations.length }}>
        {stations.map((s, i) => (
          <li key={s.id} style={{ "--i": i }}>
            <AppLink
              href={`/${locale}/stations/${s.id}`}
              className="stations__pill"
            >
              <span className="stations__pill-name">{s.name}</span>
              <span className="stations__pill-where">{s.city}</span>
            </AppLink>
          </li>
        ))}
      </ul>
    </nav>
  );
}
