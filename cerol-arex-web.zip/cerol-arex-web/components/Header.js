import AppLink from "./AppLink";
import HeaderNav from "./HeaderNav";
import LanguageSwitcher from "./LanguageSwitcher";
import { getMessages } from "@/lib/i18n";

export default function Header({ locale }) {
  const t = getMessages(locale);

  return (
    <header className="site-header">
      <AppLink href={`/${locale}`} className="site-name">
        Cerol / Arex
      </AppLink>
      <HeaderNav locale={locale} labels={t.nav} />
      <LanguageSwitcher locale={locale} />
    </header>
  );
}
