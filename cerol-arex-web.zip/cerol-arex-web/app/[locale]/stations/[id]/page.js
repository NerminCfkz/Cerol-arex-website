import Image from "next/image";
import { notFound } from "next/navigation";
import BrandIntro from "@/components/BrandIntro";
import BackLink from "@/components/BackLink";
import FuelPlates from "@/components/FuelPlates";
import ServiceList from "@/components/ServiceList";
import PhoneList from "@/components/PhoneList";
import StationMap from "@/components/StationMap";
import { stations, getStation, getServices } from "@/data/stations";
import { brands } from "@/data/brands";
import { getMessages } from "@/lib/i18n";
import { formatHours } from "@/lib/hours";
import { splitServices } from "@/lib/services";

// The background photo and the centered picture are the same file. They use the
// same `sizes`, so the browser picks the same version and downloads it only once.
// (The photo files are 1080px wide, so there is nothing bigger to pick anyway.)
const PHOTO_SIZES = "(min-width: 1080px) 1080px, 100vw";

// Builds one page per station (the locale comes from the layout).
export function generateStaticParams() {
  return stations.map((s) => ({ id: s.id }));
}

export async function generateMetadata({ params }) {
  const { id } = await params;
  const station = getStation(id);
  return { title: station ? station.name : "Not found" };
}

export default async function StationPage({ params }) {
  const { locale, id } = await params;
  const station = getStation(id);
  if (!station) notFound();

  const t = getMessages(locale);
  const brand = brands[station.brand];
  const c = brand.colors;
  const { fuel, other } = splitServices(getServices(station));

  return (
    <main
      className="station"
      style={{
        "--c-primary": c.primary,
        "--c-dark": c.dark,
        "--c-deeper": c.deeper,
        "--c-silver": c.silver,
      }}
    >
      {station.intro && brand.logo && (
        <BrandIntro brand={station.brand} logo={brand.logo} size={brand.logoSize} />
      )}

      {station.image && (
        <div className="station__photo" aria-hidden="true">
          <Image
            src={station.image}
            alt=""
            fill
            loading="eager"
            sizes={PHOTO_SIZES}
            style={{ objectPosition: station.imagePosition ?? "center" }}
          />
        </div>
      )}

      <div className="wrap">
        <BackLink locale={locale} label={t.nav.backHome} />

        {brand.logo ? (
          <span className="plate-logo">
            <Image
              src={brand.logo}
              alt={station.brand}
              width={brand.logoSize.width}
              height={brand.logoSize.height}
              loading="eager"
            />
          </span>
        ) : (
          <span className="plate-logo plate-logo--text">{station.brand}</span>
        )}

        <h1>{station.name}</h1>
        <p className="station__facts">
          {station.address}, {station.zip} {station.city}
        </p>
        <p className="station__facts">{formatHours(station.hours, t)}</p>

        {station.image && (
          <figure className="station__figure">
            <Image
              src={station.image}
              alt={t.station.photoAlt.replace("{name}", station.name)}
              fill
              loading="eager"
              fetchPriority="high"
              sizes={PHOTO_SIZES}
              style={{ objectPosition: station.imagePosition ?? "center" }}
            />
          </figure>
        )}

        <FuelPlates items={fuel} t={t} />

        <div className="sheet">
          <div>
            {other.length > 0 && (
              <section>
                <h2>{t.station.services}</h2>
                <ServiceList items={other} t={t} />
              </section>
            )}
            {station.phones.length > 0 && (
              <section>
                <h2>{t.station.contact}</h2>
                <PhoneList phones={station.phones} t={t} />
              </section>
            )}
          </div>

          <section>
            <h2>{t.station.location}</h2>
            <StationMap station={station} t={t} />
          </section>
        </div>

        <BackLink locale={locale} label={t.nav.backHome} className="back--end" />
      </div>
    </main>
  );
}
