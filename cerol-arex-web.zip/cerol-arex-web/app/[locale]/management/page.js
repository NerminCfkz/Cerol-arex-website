import InfoPage from "@/components/InfoPage";
import { getMessages } from "@/lib/i18n";

export async function generateMetadata({ params }) {
  const { locale } = await params;
  return { title: getMessages(locale).nav.management };
}

export default async function ManagementPage({ params }) {
  const { locale } = await params;
  const t = getMessages(locale);

  return <InfoPage title={t.nav.management} text={t.pages.comingSoon} />;
}
