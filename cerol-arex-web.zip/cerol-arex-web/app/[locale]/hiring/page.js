import InfoPage from "@/components/InfoPage";
import HiringForm from "@/components/HiringForm";
import { stations } from "@/data/stations";
import { getMessages } from "@/lib/i18n";

export async function generateMetadata({ params }) {
  const { locale } = await params;
  return { title: getMessages(locale).nav.hiring };
}

export default async function HiringPage({ params }) {
  const { locale } = await params;
  const t = getMessages(locale);

  return (
    <InfoPage title={t.nav.hiring} text={t.hiring.intro}>
      <HiringForm
        t={t.hiring}
        stations={stations.map((s) => ({ id: s.id, name: s.name }))}
      />
    </InfoPage>
  );
}
