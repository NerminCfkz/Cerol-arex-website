import { Fragment } from "react";
import StationNav from "@/components/StationNav";
import { stations } from "@/data/stations";
import { siteColors } from "@/data/brands";
import { getMessages } from "@/lib/i18n";

export default async function HomePage({ params }) {
  const { locale } = await params;
  const t = getMessages(locale);
  const c = siteColors;

  return (
    <main
      className="home"
      style={{
        "--c-primary": c.primary,
        "--c-dark": c.dark,
        "--c-deeper": c.deeper,
        "--c-silver": c.silver,
      }}
    >
      <div className="wrap">
        {/* The welcome message. Each line has its own animation (see .welcome in globals.css). */}
        <h1 className="welcome">
          {t.home.welcomeLines.map((line, i) => (
            <Fragment key={line}>
              <span className="welcome__line" style={{ "--i": i }}>
                <span className="welcome__text">{line}</span>
              </span>{" "}
            </Fragment>
          ))}
        </h1>
        <span className="welcome__rule" aria-hidden="true" />
        <p className="home__lead">{t.home.lead}</p>
        <StationNav
          stations={stations}
          locale={locale}
          label={t.home.chooseStation}
        />
      </div>
    </main>
  );
}
