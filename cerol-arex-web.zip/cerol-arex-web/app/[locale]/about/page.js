import InfoPage from "@/components/InfoPage";
import { getMessages } from "@/lib/i18n";

export async function generateMetadata({ params }) {
  const { locale } = await params;
  return { title: getMessages(locale).nav.about };
}

// One white box per company: a short intro, the basic facts and, when given,
// the main activities.
export default async function AboutPage({ params }) {
  const { locale } = await params;
  const t = getMessages(locale);

  return (
    <InfoPage title={t.nav.about}>
      <div className="about-grid">
        {t.about.companies.map((c) => (
          <section className="about" key={c.factsTitle}>
            <p className="about__intro">{c.intro}</p>

            <h2>{c.factsTitle}</h2>
            <dl className="about__facts">
              {c.facts.map((f) => (
                <div key={f.label}>
                  <dt>{f.label}</dt>
                  <dd>{f.value}</dd>
                </div>
              ))}
            </dl>

            {c.activities && (
              <>
                <h2>{c.activitiesTitle}</h2>
                <ul className="about__list">
                  {c.activities.map((a) => (
                    <li key={a}>{a}</li>
                  ))}
                </ul>
              </>
            )}
          </section>
        ))}
      </div>
    </InfoPage>
  );
}
