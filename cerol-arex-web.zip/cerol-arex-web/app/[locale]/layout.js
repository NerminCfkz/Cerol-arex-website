import "../globals.css";
import { Barlow, Barlow_Condensed } from "next/font/google";
import { notFound } from "next/navigation";
import { ViewTransitions } from "next-view-transitions";
import Header from "@/components/Header";
import { locales, isLocale, getMessages } from "@/lib/i18n";

// latin-ext is needed for č, ć, š, đ, ž
const body = Barlow({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const display = Barlow_Condensed({
  subsets: ["latin", "latin-ext"],
  weight: ["600", "700"],
  variable: "--font-display",
  display: "swap",
});

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export async function generateMetadata({ params }) {
  const { locale } = await params;
  const t = getMessages(locale);
  return {
    title: { default: t.site.title, template: `%s | ${t.site.title}` },
    description: t.site.description,
  };
}

export default async function LocaleLayout({ children, params }) {
  const { locale } = await params;
  if (!isLocale(locale)) notFound();

  return (
    <ViewTransitions>
      <html lang={locale} className={`${body.variable} ${display.variable}`}>
        <body>
          <Header locale={locale} />
          {children}
        </body>
      </html>
    </ViewTransitions>
  );
}
