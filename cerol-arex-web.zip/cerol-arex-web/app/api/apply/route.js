// Receives the hiring form, checks the data again on the server, makes a Word
// file (.docx) from it and e-mails it to the company (info@cerol.ba).

import { stations } from "@/data/stations";
import { buildApplicationDocx } from "@/lib/applicationDocx";
import { sendMail } from "@/lib/mail";

export const runtime = "nodejs";

const MIN_YEAR = 1940;
const MIN_AGE = 16;
const LIMITS = { firstName: 80, lastName: 80, birthYear: 4, residence: 120, station: 40, education: 200, employment: 2000 };

export async function POST(request) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false }, { status: 400 });
  }

  const clean = {};
  for (const [key, max] of Object.entries(LIMITS)) {
    const value = typeof body[key] === "string" ? body[key].trim() : "";
    if (value.length > max) return Response.json({ ok: false }, { status: 400 });
    clean[key] = value;
  }

  const year = Number(clean.birthYear);
  const maxYear = new Date().getFullYear() - MIN_AGE;
  const valid =
    clean.firstName &&
    clean.lastName &&
    clean.residence &&
    clean.education &&
    stations.some((s) => s.id === clean.station) &&
    Number.isInteger(year) &&
    year >= MIN_YEAR &&
    year <= maxYear;
  if (!valid) return Response.json({ ok: false }, { status: 400 });

  const station = stations.find((s) => s.id === clean.station);
  // One line only: a line break in a subject could be used to add mail headers.
  const oneLine = (text) => text.replace(/[\r\n]+/g, " ");
  const fullName = oneLine(`${clean.firstName} ${clean.lastName}`);
  const fileName = `Prijava_${fullName.replace(/[^\p{L}\p{N}]+/gu, "_")}.docx`;

  try {
    const file = await buildApplicationDocx(clean, station.name);
    await sendMail({
      subject: `Prijava za posao – ${station.name} – ${fullName}`,
      text: `Nova prijava za posao (${station.name}) od: ${fullName}.\nPodaci su u priloženom Word dokumentu.`,
      attachments: [
        {
          filename: fileName,
          content: file,
          contentType:
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        },
      ],
    });
  } catch (error) {
    console.error("Application e-mail failed:", error.message);
    return Response.json({ ok: false }, { status: 500 });
  }

  return Response.json({ ok: true });
}
